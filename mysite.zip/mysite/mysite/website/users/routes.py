from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import current_user, login_user, logout_user, login_required

from website import bcrypt, db
from website.models import User, Cart, Library, CardDetails, WishList
from website.users.forms import SignUp, Login, UpdatePassword, UpdateEmail

# Blueprint
users = Blueprint('users', __name__)


@users.route('/signup', methods=['GET', 'POST'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))

    form = SignUp()
    if form.validate_on_submit():
        email = form.email.data
        password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        age = form.age.data
        country = form.country.data
        user = User(email=email, password=password, age=age, country=country)
        db.session.add(user)
        db.session.commit()
        login_user(user, remember=form.remember.data)
        flash('Account created successfully', 'success')
        return redirect(url_for('main.home'))

    return render_template('user/signup.html', title='Sign up', form=form)


@users.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))

    form = Login()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            flash('Login successful', 'success')
            prev = request.args.get('next')
            if prev:
                return redirect(prev)
            return redirect(url_for('main.home'))
        else:
            flash('Login unsuccessful. Incorrect email or password!', 'danger')
            return redirect(url_for('users.login'))
    return render_template('user/login.html', title='Login', form=form)


@users.route('/account', methods=['GET', 'POST'])
@login_required
def account():
    cards = CardDetails.query.filter_by(owner=current_user).all()
    amount = len(Library.query.filter_by(bought_by=current_user).all())
    return render_template('user/account_settings.html', title='Account', cards=cards, number=len(cards), amount=amount)


@users.route('/logout')
def logout():
    if current_user.is_authenticated:
        logout_user()
        return redirect(url_for('main.home'))
    else:
        return redirect(url_for('main.home'))


@users.route('/account/update-email', methods=['GET', 'POST'])
@login_required
def update_email():
    form = UpdateEmail()
    if request.method == 'GET':
        form.email.data = current_user.email
    elif form.validate_on_submit():
        user = User.query.filter_by(email=current_user.email).first()
        user.email = form.email.data
        db.session.commit()
        flash('Your email has been updated!', 'success')
        return redirect(url_for('users.account'))
    return render_template('user/update_email.html', title='Account', form=form)


@users.route('/account/update-password', methods=['GET', 'POST'])
@login_required
def update_password():
    form = UpdatePassword()

    if form.validate_on_submit():
        user = User.query.filter_by(email=current_user.email).first()
        if bcrypt.check_password_hash(user.password, form.current_password.data):
            user.password = bcrypt.generate_password_hash(form.new_password.data)
            db.session.commit()
            flash('Your password has been updated!', 'success')
            return redirect(url_for('users.account'))
        else:
            flash('Your current password is incorrect.', 'danger')
    return render_template('user/update_password.html', title='Account', form=form)


@users.route('/cart')
@login_required
def cart():
    cart_list = Cart.query.filter_by(buyer=current_user).all()
    total = sum(comic.book.price for comic in cart_list)
    return render_template('user/cart.html', title='Cart', items=cart_list, length=len(cart_list),
                           total=total)


@users.route('/wishlist')
@login_required
def wishlist():
    wish_list = WishList.query.filter_by(buyer=current_user).all()
    in_cart = Cart.query.filter_by(buyer=current_user).first()
    return render_template('user/wishlist.html', title='Cart', items=wish_list, length=len(wish_list), in_cart=in_cart is not None)


@users.route('/library')
@login_required
def library():
    page = request.args.get('page', 1, type=int)
    library_items = Library.query.filter_by(bought_by=current_user).paginate(page=page, per_page=8)
    return render_template('user/library.html', title='Library', items=library_items,
                           length=library_items.total, len=len)
