from datetime import datetime

from flask import Blueprint, flash, redirect, url_for, render_template, request, abort
from flask_login import login_required, current_user

from website import db
from website.models import ComicBook, Library, Cart, WishList, Episode
from website.admin.forms import AddComic, AddEpisode

admin = Blueprint('admin', __name__)


# admin pass: Th1s_1s_th3_Adm1n-open_up


@admin.route('/admin')
@login_required
def admin_home():
    if current_user.email != 'admin@admin.com':
        abort(403)

    return render_template('admin/home.html', title='Admin')


# Add a book
@admin.route('/admin/add-comic', methods=['GET', 'POST'])
@login_required
def add_comic():
    if current_user.email != 'admin@admin.com':
        abort(403)

    form = AddComic()

    if form.validate_on_submit():
        category = form.category.data
        title = form.title.data
        author = form.author.data.title()
        illustrator = form.illustrator.data.title()
        price = form.price.data
        release_date = form.date.data.strftime('%d/%m/%Y')
        description = form.description.data
        top_pick = form.top_pick.data
        filename = form.cover_image.data.filename
        title_query = form.cover_image.data.filename[:-4].lower()
        category_query = category.replace(':', '').replace('\'', '').replace(' ', '-').lower()
        book = ComicBook(category=category, title=title, author=author, illustrator=illustrator, price=price,
                         release_date=release_date, description=description, top_pick=top_pick, filename=filename,
                         title_query=title_query, category_query=category_query)
        db.session.add(book)
        db.session.commit()

        flash('Book added to shelves. ', 'success')
        return redirect(url_for('admin.add_comic'))

    return render_template('admin/add_book.html', title='Add a book', form=form)


@admin.route('/admin/update-book')
@login_required
def all_comics():
    if current_user.email != 'admin@admin.com':
        abort(403)

    page = request.args.get('page', 1, type=int)
    comics = ComicBook.query.paginate(page=page, per_page=4)
    return render_template('admin/all_comics.html', title='Update', comics=comics)


@admin.route('/admin/update-book/<title_query>', methods=['GET', 'POST'])
@login_required
def update_comic(title_query):
    if current_user.email != 'admin@admin.com':
        abort(403)

    form = AddComic()

    book = ComicBook.query.filter_by(title_query=title_query).first()

    if request.method == 'GET':
        form.category.data = book.category
        form.title.data = book.title
        form.author.data = book.author
        form.illustrator.data = book.illustrator
        form.price.data = book.price
        form.date.data = datetime.strptime(book.release_date, '%d/%m/%Y')
        form.description.data = book.description
        form.top_pick.data = book.top_pick

    if form.validate_on_submit():
        book.filename = form.cover_image.data.filename
        book.category = form.category.data
        book.title = form.title.data
        book.author = form.author.data.title()
        book.illustrator = form.illustrator.data.title()
        book.price = form.price.data
        book.release_date = form.date.data.strftime('%d/%m/%Y')
        book.description = form.description.data
        book.title_query = form.cover_image.data.filename[:-4].lower()
        book.category_query = form.category.data.replace(':', '').replace('\'', '').replace(' ', '-').lower()
        db.session.commit()
        flash(f'Comic has been updated', 'success')
        return redirect(url_for('admin.all_comics'))

    return render_template('admin/add_book.html', title='Add a book', form=form)


@admin.route('/admin/delete-book/<title_query>', methods=['GET', 'POST'])
@login_required
def delete_book(title_query):
    if current_user.email != 'admin@admin.com':
        abort(403)

    page = request.args.get('page', 1, type=int)
    comic = ComicBook.query.filter_by(title_query=title_query).first()
    lib = Library.query.filter_by(book=comic).all()
    cart = Cart.query.filter_by(book=comic).all()
    wish = WishList.query.filter_by(book=comic).all()

    # Remove from every library, cart and wishlist if a book is deleted from the database
    for i in lib:
        db.session.delete(i)
    for j in cart:
        db.session.delete(j)
    for k in wish:
        db.session.delete(k)
    db.session.delete(comic)
    db.session.commit()
    return redirect(url_for('admin.all_comics', page=page))


# ============================== Episodes =====================================
@admin.route('/admin/add-episode', methods=['GET', 'POST'])
@login_required
def add_episode():
    if current_user.email != 'admin@admin.com':
        abort(403)

    form = AddEpisode()

    if form.validate_on_submit():
        series = form.series.data
        name = form.name.data
        director = form.director.data
        release_date = form.date.data.strftime('%d/%m/%Y')
        description = form.description.data
        name_query = name.replace(' - ', '-').replace(':', '').replace('\'', '').replace(' ', '-').lower()
        series_query = series.replace(' - ', '-').replace(':', '').replace('\'', '').replace(' ', '-').lower()
        episode_num = len(Episode.query.filter_by(series_query=series_query).all()) + 1
        episode = Episode(series=series, name=name, director=director,
                          release_date=release_date, description=description,
                          name_query=name_query, series_query=series_query, episode_num=episode_num)
        db.session.add(episode)
        db.session.commit()

        flash('Episode added. ', 'success')
        return redirect(url_for('admin.add_episode'))

    return render_template('admin/add_episode.html', title='Add an episode', form=form)


@admin.route('/admin/all-episodes')
@login_required
def all_episodes():
    if current_user.email != 'admin@admin.com':
        abort(403)

    page = request.args.get('page', 1, type=int)
    episodes = Episode.query.paginate(page=page, per_page=4)
    return render_template('admin/all_episodes.html', title='Update', episodes=episodes)


@admin.route('/admin/update-episode/<name_query>', methods=['GET', 'POST'])
@login_required
def update_episode(name_query):
    if current_user.email != 'admin@admin.com':
        abort(403)

    form = AddEpisode()

    episode = Episode.query.filter_by(name_query=name_query).first()

    if request.method == 'GET':
        form.series.data = episode.series
        form.name.data = episode.name
        form.director.data = episode.director
        form.date.data = datetime.strptime(episode.release_date, '%d/%m/%Y')
        form.description.data = episode.description

    if form.validate_on_submit():
        episode.series = form.series.data
        episode.name = form.name.data
        episode.director = form.director.data.title()
        episode.release_date = form.date.data.strftime('%d/%m/%Y')
        episode.description = form.description.data
        episode.name_query = form.name.data.replace(' - ', '-').replace(':', '').replace('\'', '').replace(' ', '-').lower()
        episode.series_query = form.series.data.replace(' - ', '-').replace(':', '').replace('\'', '').replace(' ', '-').lower()
        db.session.commit()
        flash(f'Episode has been updated', 'success')
        return redirect(url_for('admin.all_episodes'))

    return render_template('admin/add_episode.html', title='Update an episode', form=form)


@admin.route('/admin/delete-episode/<name_query>', methods=['GET', 'POST'])
@login_required
def delete_episode(name_query):
    if current_user.email != 'admin@admin.com':
        abort(403)

    page = request.args.get('page', 1, type=int)
    episode = Episode.query.filter_by(name_query=name_query).first()
    episodes = Episode.query.all()
    index = episodes.index(episode)

    for i in episodes[index:]:
        i.episode_num -= 1

    # Remove from every library, cart and wishlist if a book is deleted from the database
    db.session.delete(episode)
    db.session.commit()
    return redirect(url_for('admin.all_episodes', page=page))
