from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SubmitField, BooleanField, IntegerField, DateField
from wtforms.validators import DataRequired, Length


class AddComic(FlaskForm):
    cover_image = FileField('Book cover', validators=[FileAllowed(['jpg', 'png']), DataRequired()])
    category = StringField('Category', validators=[DataRequired()])
    title = StringField('Title', validators=[DataRequired()])
    author = StringField('Author', validators=[DataRequired()])
    illustrator = StringField('Illustrator', validators=[DataRequired()])
    price = IntegerField('Price', validators=[DataRequired()], default=0)
    date = DateField('Date', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired(), Length(max=300)])
    top_pick = BooleanField('Best seller')
    submit = SubmitField('Add Book')


class AddEpisode(FlaskForm):
    series = StringField('Series', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    director = StringField('Director', validators=[DataRequired()])
    date = DateField('Date', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired(), Length(max=300)])
    submit = SubmitField('Add Episode')
