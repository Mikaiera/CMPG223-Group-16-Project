from flask import Blueprint, redirect, url_for, flash, abort, request
from flask_login import current_user, login_required

from website import db
from website.models import ComicBook, Cart, WishList, CardDetails

action = Blueprint('action', __name__)


@action.route('/add-to-cart/<title_query>', methods=['GET', 'POST'])
@login_required
def add_to_cart(title_query):
    item = Cart(book=ComicBook.query.filter_by(title_query=title_query).first(), buyer=current_user)
    db.session.add(item)
    db.session.commit()
    flash('Item added to cart!', 'success')

    if request.args.get('next') is None:
        return redirect(url_for('main.comic_info', title_query=title_query))
    else:
        return redirect(request.args.get('next'))


@action.route('/remove-from-cart/<title_query>', methods=['GET', 'POST'])
@login_required
def remove_from_cart(title_query):
    book = (Cart.query.filter_by(book=ComicBook.query.filter_by(title_query=title_query).first(), buyer=current_user)
            .first())

    if current_user != book.buyer:
        abort(403)

    db.session.delete(book)
    db.session.commit()

    if request.args.get('next') is None:
        return redirect(url_for('users.cart'))
    else:
        return redirect(request.args.get('next'))


@action.route('/add-to-wishlist/<title_query>', methods=['GET', 'POST'])
@login_required
def add_to_wishlist(title_query):
    item = WishList(book=ComicBook.query.filter_by(title_query=title_query).first(), buyer=current_user)
    db.session.add(item)
    db.session.commit()
    flash('Item added to wishlist.', 'success')

    if request.args.get('next') is None:
        return redirect(url_for('main.comic_info', title_query=title_query))
    else:
        return redirect(request.args.get('next'))


@action.route('/remove-from-wishlist/<title_query>', methods=['GET', 'POST'])
@login_required
def remove_from_wishlist(title_query):
    book = WishList.query.filter_by(book=ComicBook.query.filter_by(title_query=title_query).first(),
                                    buyer=current_user).first()

    if current_user != book.buyer:
        abort(403)

    db.session.delete(book)
    db.session.commit()
    flash('Item removed from wishlist.', 'success')

    if request.args.get('next') is None:
        return redirect(url_for('main.comic_info', title_query=title_query))
    else:
        return redirect(request.args.get('next'))


@action.route('/delete-payment-method/<card_number>', methods=['GET', 'POST'])
@login_required
def delete_payment_method(card_number):
    card = CardDetails.query.filter_by(card_number=card_number).first()
    db.session.delete(card)
    db.session.commit()

    if request.args.get('next') is None:
        return redirect(url_for('users.account',))
    else:
        return redirect(request.args.get('next'))
