import json
# import os

# print(os.getcwd())

try:
    with open('mysite/config.json', 'r') as conf:
        data = json.load(conf)

except FileNotFoundError:
    print('Configuration file not found. Cannot start application.')
    exit(1)


class Config:
    SECRET_KEY = data['SECRET_KEY']
    SQLALCHEMY_DATABASE_URI = data['SQLALCHEMY_DATABASE_URI']
    MAIL_SERVER = data['MAIL_SERVER']
    MAIL_PORT = data['MAIL_PORT']
    MAIL_USE_TLS = data['MAIL_USE_TLS']
    MAIL_USE_SSL = data['MAIL_USE_SSL']
    MAIL_USERNAME = data['MAIL_USERNAME']
    MAIL_PASSWORD = data['MAIL_PASSWORD']
